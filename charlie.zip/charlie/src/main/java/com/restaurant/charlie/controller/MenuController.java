package com.restaurant.charlie.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.restaurant.charlie.dao.MenuRepository;
import com.restaurant.charlie.dao.UserRepository;
import com.restaurant.charlie.entity.MenuItem;
import com.restaurant.charlie.entity.User;
import com.restaurant.charlie.serviceImpl.ServiceImpl;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins= "http://localhost:4200")
@RequestMapping("api/v1")
public class MenuController {
	@Autowired
	private ServiceImpl serviceImpl;
	
	@GetMapping("/menulist")
	public List<MenuItem> showUsers() {
		return serviceImpl.getMenuItems();
	}
	@PostMapping("/addmenu")
	public void createUser(@RequestBody MenuItem user) {
		serviceImpl.addMenuItem(user);
	}

}
