package com.restaurant.charlie.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.restaurant.charlie.dao.CartRepository;
import com.restaurant.charlie.dao.MenuRepository;
import com.restaurant.charlie.dao.UserRepository;
import com.restaurant.charlie.entity.Cart;
import com.restaurant.charlie.entity.MenuItem;
import com.restaurant.charlie.entity.User;
import com.restaurant.charlie.service.Service;

@Component
public class ServiceImpl implements Service {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private MenuRepository menuRepository;
	@Override
	public List<User> getUsers() {
		return userRepository.findAll();
	}

	@Override
	public List<MenuItem> getMenuItems() {
		return menuRepository.findAll();
	}

	@Override
	public List<Cart> getCart() {
		return cartRepository.findAll();
	}

	@Override
	public User addUser(User user) {
		return userRepository.save(user);
	}

	@Override
	public Cart saveCart(Cart cart) {
		return cartRepository.save(cart);
	}

	@Override
	public MenuItem addMenuItem(MenuItem menuItem) {
		return menuRepository.save(menuItem);
	}

}
