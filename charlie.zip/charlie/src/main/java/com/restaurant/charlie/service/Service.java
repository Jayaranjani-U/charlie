package com.restaurant.charlie.service;

import java.util.List;

import com.restaurant.charlie.entity.Cart;
import com.restaurant.charlie.entity.MenuItem;
import com.restaurant.charlie.entity.User;

public interface Service {
	public List<User> getUsers();
	public List<MenuItem> getMenuItems();
	public List<Cart> getCart();
	public User addUser(User user);
	public Cart saveCart(Cart cart);

	public MenuItem addMenuItem(MenuItem menuItem);

}
