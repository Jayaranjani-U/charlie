package com.restaurant.charlie.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.restaurant.charlie.entity.MenuItem;

@Repository
@Component
public interface MenuRepository extends JpaRepository<MenuItem,Long>{

}
